package com.example.HelloCrud.controller;

import com.example.HelloCrud.model.Journey;
import com.example.HelloCrud.JourneyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;
import java.util.UUID;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login"; // Return the name of the login HTML file (e.g., login.html)
    }

    // Add POST mapping for form submission and authentication if needed
}
