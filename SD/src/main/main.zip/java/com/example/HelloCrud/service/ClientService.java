package com.example.HelloCrud.service;


import com.example.HelloCrud.ClientRepository;
import com.example.HelloCrud.model.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService {

    private final ClientRepository clientRepository;

    @Autowired
    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public Client findByUsername(String username) {
        return clientRepository.findByUsername(username);
    }
}
