package com.example.HelloCrud;


import com.example.HelloCrud.model.Client;
import com.example.HelloCrud.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

@Component
public class CustomPasswordEncoder extends DaoAuthenticationProvider {

    private final ClientService clientService;

    @Autowired
    public CustomPasswordEncoder(UserDetailsService userDetailsService, ClientService clientService) {
        setUserDetailsService(userDetailsService);
        this.clientService = clientService;
    }

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        Client client = clientService.findByUsername(username);

        if (client == null || !password.equals(client.getPassword())) {
            throw new BadCredentialsException("Invalid username or password");
        }
    }
}
