package com.example.HelloCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloCrudApplication.class, args);
	}

}
