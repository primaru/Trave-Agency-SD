package com.example.HelloCrud.controller;

import com.example.HelloCrud.model.Journey;
import com.example.HelloCrud.service.JourneyService;
import com.example.HelloCrud.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDate;

@Controller
public class JourneyController {

    @Autowired
    private JourneyService journeyService;

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/confirmJourney")
    public String confirmJourney(HttpSession session, Model model) {
        Journey selectedJourney = (Journey) session.getAttribute("selectedJourney");
        if (selectedJourney == null) {
            return "redirect:/dashboard";
        }
        model.addAttribute("journey", selectedJourney);
        return "confirmJourney";
    }

    @PostMapping("/processTransaction")
    public String processTransaction(HttpSession session, @RequestParam String address, Model model) {
        Journey selectedJourney = (Journey) session.getAttribute("selectedJourney");
        String transactionId = (String) session.getAttribute("transactionId");

        if (selectedJourney == null || transactionId == null) {
            return "redirect:/dashboard";
        }

        LocalDate dispatchDate = transactionService.processTransaction(selectedJourney, address, transactionId);
        model.addAttribute("dispatchDate", dispatchDate);

        session.removeAttribute("transactionId");
        session.removeAttribute("selectedJourney");

        return "transactionSuccess";
    }

}
