package com.example.HelloCrud;


import com.example.HelloCrud.CustomPasswordEncoder;
import com.example.HelloCrud.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private UserDetailsService userDetailsService; // Inject your UserDetailsService here

    @Autowired
    private ClientService clientService; // Inject your ClientService here

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((authz) -> authz
                        .requestMatchers("/", "/home", "/register").permitAll()
                        .anyRequest().authenticated()
                )
                .formLogin((form) -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/dashboard",true) // Redirect to /dashboard on successful login
                        .permitAll()
                )
                .logout((logout) -> logout.permitAll())
                .authenticationProvider(customAuthenticationProvider()); // Add custom AuthenticationProvider here

        return http.build();
    }

    @Bean
    public CustomPasswordEncoder customAuthenticationProvider() {
        return new CustomPasswordEncoder(userDetailsService, clientService);
    }
}
